@echo off
chcp 65001 > nul
echo ========================================================
echo    NOVAX - رفع المشروع إلى GitHub وتفعيل الموقع
echo ========================================================
echo.

set /p REPO_URL="أدخل رابط مستودع GitHub الخاص بك (مثال: https://github.com/username/novax.git): "

if "%REPO_URL%"=="" (
    echo [خطأ] لم تقم بإدخال الرابط!
    pause
    exit /b
)

echo.
echo [1/4] تهيئة مستودع Git محلياً...
git init

echo.
echo [2/4] إضافة وتجهيز كافة الملفات...
git add .
git commit -m "Deploy NOVAX official platform"

echo.
echo [3/4] ربط المستودع بـ GitHub...
git branch -M main
git remote remove origin 2>nul
git remote add origin %REPO_URL%

echo.
echo [4/4] جاري الرفع إلى GitHub...
git push -u origin main --force

echo.
echo ========================================================
echo   تم الرفع بنجاح!
echo   لتفعيل الموقع أونلاين:
echo   1. اذهب لمستودعك على GitHub
echo   2. Settings -> Pages -> اختر فرع main واضغط Save
echo ========================================================
pause
